
int getVCFHeader(const char *fname);
int getVCFHeaderAll(const char *fname);
